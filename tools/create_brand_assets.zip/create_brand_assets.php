<?php
// C:\xampp\htdocs\pendenz.com\tools\create_brand_assets.php
declare(strict_types=1);

ini_set('display_errors', '1');
error_reporting(E_ALL);

$root = realpath(__DIR__ . '/..');
if (!$root) {
    http_response_code(500);
    exit("Root not found\n");
}

$assetsDir = $root . '/assets';
$brandDir  = $assetsDir . '/brand';

@mkdir($assetsDir, 0775, true);
@mkdir($brandDir, 0775, true);

function make_png(int $w, int $h, string $bgHex, ?callable $draw = null): string {
    $im = imagecreatetruecolor($w, $h);
    imagealphablending($im, true);
    imagesavealpha($im, true);

    // Hintergrund
    $bgHex = ltrim($bgHex, '#');
    $r = hexdec(substr($bgHex, 0, 2));
    $g = hexdec(substr($bgHex, 2, 2));
    $b = hexdec(substr($bgHex, 4, 2));
    $bg = imagecolorallocate($im, $r, $g, $b);
    imagefilledrectangle($im, 0, 0, $w, $h, $bg);

    if ($draw) $draw($im, $w, $h);

    ob_start();
    imagepng($im);
    $png = ob_get_clean();
    imagedestroy($im);
    return $png ?: '';
}

// Farben
$teal   = '#0EA5A0';
$tealD  = '#0B7E7A';
$white  = '#FFFFFF';

// 16x16
$fav16 = make_png(16, 16, $tealD, function($im, $w, $h) use ($white) {
    $c = imagecolorallocate($im, 255,255,255);
    imagestring($im, 2, 4, 2, 'P', $c);
});
file_put_contents($brandDir . '/favicon-16.png', $fav16);

// 32x32
$fav32 = make_png(32, 32, $teal, function($im, $w, $h) use ($white) {
    $c = imagecolorallocate($im, 255,255,255);
    imagestring($im, 5, 10, 8, 'P', $c);
});
file_put_contents($brandDir . '/favicon-32.png', $fav32);

// 180x180 (Apple touch)
$apple = make_png(180, 180, '#FFFFFF', function($im, $w, $h) use ($teal) {
    // Kreis in Türkis
    $rgb = [
        hexdec(substr(ltrim($teal, '#'), 0, 2)),
        hexdec(substr(ltrim($teal, '#'), 2, 2)),
        hexdec(substr(ltrim($teal, '#'), 4, 2)),
    ];
    $c = imagecolorallocate($im, $rgb[0], $rgb[1], $rgb[2]);
    imagefilledellipse($im, $w/2, $h/2, 140, 140, $c);
});
file_put_contents($brandDir . '/apple-touch-icon.png', $apple);

// 512x512 Logo (einfacher Kasten + „P“)
$logo = make_png(512, 512, $teal, function($im, $w, $h) use ($white) {
    $c = imagecolorallocate($im, 255,255,255);
    // dicker Rahmen
    imagesetthickness($im, 14);
    imagerectangle($im, 20, 20, $w-20, $h-20, $c);
    // großes P
    imagestring($im, 5, 220, 230, 'P', $c);
});
file_put_contents($brandDir . '/logo-mark.png', $logo);

// Manifest
$useBase = '/pendenz.com/'; // wenn live im Webroot, hier zu "/" ändern
$manifest = [
    "name" => "pendenz.com",
    "short_name" => "pendenz",
    "start_url" => $useBase,
    "display" => "standalone",
    "background_color" => "#ffffff",
    "theme_color" => "#0ea5a0",
    "icons" => [
        ["src" => "brand/favicon-16.png",       "sizes" => "16x16",   "type" => "image/png"],
        ["src" => "brand/favicon-32.png",       "sizes" => "32x32",   "type" => "image/png"],
        ["src" => "brand/apple-touch-icon.png", "sizes" => "180x180", "type" => "image/png", "purpose" => "maskable any"],
        ["src" => "brand/logo-mark.png",        "sizes" => "512x512", "type" => "image/png", "purpose" => "any"],
    ]
];
file_put_contents($assetsDir . '/site.webmanifest', json_encode($manifest, JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT));

header('Content-Type: text/plain; charset=utf-8');
echo "OK\n\n";
echo "Created:\n";
echo " - " . $brandDir . "/favicon-16.png\n";
echo " - " . $brandDir . "/favicon-32.png\n";
echo " - " . $brandDir . "/apple-touch-icon.png\n";
echo " - " . $brandDir . "/logo-mark.png\n";
echo " - " . $assetsDir . "/site.webmanifest\n";
